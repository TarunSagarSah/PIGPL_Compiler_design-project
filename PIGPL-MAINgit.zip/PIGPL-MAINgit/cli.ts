#!/usr/bin/env node
/**
 * PiGPL Command Line Interface (CLI) Runner
 * 
 * Compile and execute PiGPL programs directly from the terminal.
 * Course: Compiler Design Laboratory
 * Student: Tarun Sagar Sah (24BKT0017)
 */
import fs from "node:fs";
import path from "node:path";
import { compile } from "./src/compiler/pipeline.ts";
import { resultToReport, resultToJSON } from "./src/compiler/export.ts";
import { GRAMMAR } from "./src/compiler/examples.ts";

function printHelp() {
  console.log(`
PiGPL Compiler & Execution CLI (v1.0.0)
Usage:
  node --experimental-strip-types cli.ts <source-file.pigpl> [options]
  npm run pigpl -- <source-file.pigpl> [options]

Options:
  --tokens       Display the lexical token stream
  --ast          Display Abstract Syntax Tree structure
  --symbols      Display the scoped symbol table
  --semantic     Display semantic validation checks
  --tac          Display generated Three-Address Code (quadruples)
  --opt          Display optimized TAC and optimization transformations
  --report       Display full end-to-end compilation report
  --json         Output full compilation result as JSON
  --grammar      Display the formal PiGPL language grammar
  --bench        Measure compilation and execution duration
  --help, -h     Show this help message

Examples:
  node --experimental-strip-types cli.ts examples/factorial.pigpl
  node --experimental-strip-types cli.ts examples/factorial.pigpl --tokens --ast --tac
  node --experimental-strip-types cli.ts examples/factorial.pigpl --report
`);
}

function main() {
  const args = process.argv.slice(2);
  if (args.length === 0 || args.includes("-h") || args.includes("--help")) {
    printHelp();
    process.exit(0);
  }

  if (args.includes("--grammar")) {
    console.log("=== PiGPL Formal Language Grammar ===");
    console.log(GRAMMAR);
    process.exit(0);
  }

  const flags = new Set(args.filter((a) => a.startsWith("-")));
  const files = args.filter((a) => !a.startsWith("-"));

  if (files.length === 0) {
    console.error("Error: No input file specified.");
    printHelp();
    process.exit(1);
  }

  const filePath = path.resolve(process.cwd(), files[0]);
  if (!fs.existsSync(filePath)) {
    console.error(`Error: File not found: ${filePath}`);
    process.exit(1);
  }

  const source = fs.readFileSync(filePath, "utf-8");
  const startTime = performance.now();
  const result = compile(source);
  const compTime = performance.now() - startTime;

  if (flags.has("--json")) {
    console.log(JSON.stringify(resultToJSON(result), null, 2));
    process.exit(result.errors.length > 0 ? 1 : 0);
  }

  if (flags.has("--report")) {
    console.log(resultToReport(result));
    process.exit(result.errors.length > 0 ? 1 : 0);
  }

  if (flags.has("--tokens")) {
    console.log("\n--- [Stage 1 & 2: Token Stream] ---");
    for (const t of result.tokens) {
      console.log(`  Line ${String(t.line).padStart(3)}:${String(t.column).padEnd(3)}  ${t.type.padEnd(12)}  ${t.lexeme}`);
    }
  }

  if (flags.has("--ast")) {
    console.log("\n--- [Stage 3 & 4: Abstract Syntax Tree] ---");
    console.log(JSON.stringify(result.tree, null, 2));
  }

  if (flags.has("--symbols")) {
    console.log("\n--- [Stage 5: Scoped Symbol Table] ---");
    console.log(`  ${"NAME".padEnd(14)} ${"TYPE".padEnd(12)} ${"SCOPE".padEnd(14)} ${"KIND".padEnd(8)} VALUE`);
    console.log("  " + "-".repeat(56));
    for (const s of result.symbols) {
      console.log(`  ${s.name.padEnd(14)} ${s.varType.padEnd(12)} ${s.scope.padEnd(14)} ${s.kind.padEnd(8)} ${JSON.stringify(s.value)}`);
    }
  }

  if (flags.has("--semantic")) {
    console.log("\n--- [Stage 6: Semantic Analysis Checks] ---");
    for (const c of result.checks) {
      console.log(`  [${c.ok ? "PASS" : "FAIL"}] (Line ${c.line}:${c.column}) ${c.message}`);
    }
  }

  if (flags.has("--tac")) {
    console.log("\n--- [Stage 7: Intermediate Code (Three-Address Code)] ---");
    result.ir.forEach((q, i) => {
      console.log(`  ${String(i).padStart(3)}: ${q.text}`);
    });
  }

  if (flags.has("--opt")) {
    console.log("\n--- [Stage 8: Optimized Three-Address Code] ---");
    result.optimizedIr.forEach((q, i) => {
      console.log(`  ${String(i).padStart(3)}: ${q.text}`);
    });
    if (result.optimizations.length > 0) {
      console.log(`\n  Applied ${result.optimizations.length} optimization passes:`);
      for (const opt of result.optimizations) {
        console.log(`    - [${opt.kind}] ${opt.message} : ${opt.before} -> ${opt.after}`);
      }
    } else {
      console.log("  (No algebraic or constant-folding optimizations required)");
    }
  }

  if (result.errors.length > 0) {
    console.error("\n❌ Compilation failed with diagnostics:");
    for (const err of result.errors) {
      console.error(`  [${err.phase} Error] (Line ${err.line}, Column ${err.column}): ${err.message}`);
    }
    process.exit(1);
  }

  if (result.execution) {
    if (flags.size > 0 && !flags.has("--bench")) {
      console.log("\n--- [Stage 9: Target Execution Output] ---");
    }
    if (result.execution.output.length > 0) {
      for (const line of result.execution.output) {
        console.log(line);
      }
    } else {
      console.log("(Program executed cleanly with no printed output)");
    }

    if (result.execution.error) {
      console.error(`\n❌ Runtime Error: ${result.execution.error.message} (Line ${result.execution.error.line})`);
      process.exit(2);
    }
  }

  if (flags.has("--bench")) {
    console.log(`\n[Benchmark]: Compilation took ${compTime.toFixed(3)} ms. Execution steps: ${result.execution?.steps.length ?? 0}`);
  }
}

main();

