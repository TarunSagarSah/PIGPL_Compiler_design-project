# PiGPL

PiGPL (Python-inspired General Purpose Language) is a small language whose compiler is built to be watched. Source is not a black box: characters become tokens, tokens become a grammar tree, the tree is checked, names enter a symbol table, the tree becomes three-address code, and that code is optimized.

## Language

```
let x: int = 10
let y: int = 20
let z: int = x + y

if z > 20 {
    print("Greater")
} else {
    print("Not greater")
}
```

| Area | Forms |
| --- | --- |
| Types | `int`, `float`, `bool`, `string`, `list` |
| Declarations | `let name: type = expr` |
| Control | `if` / `elif` / `else`, `while`, `for i in expr` |
| Functions | `fn name(a: int) -> int { return a }` |
| Operators | `+ - * / %`, `== != < > <= >=`, `and or not` |
| Comments | `#` to end of line |

`for i in n` iterates `0 .. n-1` when `n` is an `int`. `for v in xs` walks a list.

## Pipeline

```
Source → Lexer → Tokens → Parser → AST → Symbol table → Semantic → TAC → Optimize → Execute
```

Every stage emits events. Play / step / seek replays the same compilation: the visualization is the compiler log, not a separate animation.

## Examples

The editor ships programs for arithmetic, control flow, lists, recursion, constant folding, and phase-tagged lexical / syntax / semantic errors.
